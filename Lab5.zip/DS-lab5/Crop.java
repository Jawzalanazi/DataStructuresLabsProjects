public class Crop{
    String name ;
    int id;
    int numKilos;
    int daysToHarvest;

    public Crop(String name, int id, int numKilos, int daysToHarvest) {
        this.name = name;
        this.id = id;
        this.numKilos = numKilos;
        this.daysToHarvest = daysToHarvest;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getNumKilos() {
        return numKilos;
    }

    public void setNumKilos(int numKilos) {
        this.numKilos = numKilos;
    }

    public int getDaysToHarvest() {
        return daysToHarvest;
    }

    public void setDaysToHarvest(int daysToHarvest) {
        this.daysToHarvest = daysToHarvest;
    }

public String toString(){
    return String.format (" Name: %s, ID:%d, Number of Kilos: %d, Days Till Harvest: %d " , name , id, numKilos, daysToHarvest);
}

}