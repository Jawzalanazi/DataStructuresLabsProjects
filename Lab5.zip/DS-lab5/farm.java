// jawza fahad alanazi
// 443020299

import java.util.Scanner;
public class farm {
    
    public static Crop array[] = new Crop[6];

    public static void addCrop(){
        array[0] = new Crop("Corn", 1234, 576, 45);
        array[1] = new Crop("Apple", 2345, 235, 33);
        array[2] = new Crop("Orange", 1336, 417, 60);
        array[3] = new Crop("Date", 6524, 500, 38);
        array[4] = new Crop("Watermelon", 8787, 683, 15);
        array[5] = new Crop("Wheat", 4644, 264, 25);
    }

    public static void printCrop(){
        for( int i=0; i< array.length; i++)
        System.out.println(array[i]);
    }

    public static void bubbleSort(Crop[]array){
         for( int i=0; i< array.length; i++){
             for( int j=0; j< array.length-i; j++){
                if(array[j-1].getName().compareTo(array[j].getName())>0){
                    Crop temp = array[j-1];
                    array[j-1] = array[j];
                    array[j] = temp;
                }
             }
         }
    }

    public static void QuickSort(Crop[]arrays, int start, int end){
        if(start >= end)
        return ;

        int left = start;
        int right = end-1;
        Crop pivot = arrays[end];
        
        while (left <= right){
            while(left <= right && arrays[left].getId() < pivot.getId()){
                left ++;
            }
            while(left <= right && arrays[right].getId() > pivot.getId()){
                right --;
        }
        if(left <= right){
            Crop temp = arrays[right];
            arrays[right] = arrays[left];
             arrays[left] = temp;
             left ++;
             right--;
        }
        arrays[end] = arrays[left];
        arrays[left] = pivot;
    }
}
    public static void printInfo(){
        for( int i=0; i< array.length; i++){
             for( int j=0; j< array.length-i; j++){
                if(array[j-1].getDaysToHarvest()>array[j].daysToHarvest){
                      Crop temp = array[j-1];
                      array[j-1] = array[j];
                      array[j] = temp;
               }
             }
             System.out.println(array[0].daysToHarvest);
    }
    
    }

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
         int choice=0;
         do{
             System.out.println("1- add Agricultural Crops");
             System.out.println("2- print All Crops");
             System.out.println("3- QuickSort by ID" );
             System.out.println("4- bubbleSort by Name ");
             System.out.println("5- Exit");
             System.out.println("Enter your Choice ");
             choice=input.nextInt();
             switch(choice){
                 case 1:
                     addCrop();
                     break;
                 case 2:
                     printCrop();
                     break;
                 case 3:
                     QuickSort(array,0, array.length-1);
                     break;
                 case 4:
                     bubbleSort(array);
                     break;
                 case 5:
                     break;
             }
             
         }while(choice!=5);
 } 
}