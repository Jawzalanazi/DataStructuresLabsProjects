public class HashTable {
    private int[] buffer;

    public HashTable(int N) {
        buffer = new int[N];
        for (int i = 0; i < N; i++) {
            buffer[i] = -1;
        }
    }

    public void empty() {
        for (int i = 0; i < buffer.length; i++) {
            buffer[i] = -1;
        }
    }

    public static int hash(int a, int b, int N, int k) {
        return (a * k + b) % N;
    }

    public static int linearProbing(int a, int b, int N, int k, int i) {
        return (a * k + b + i) % N;
    }

    public static int quadraticProbing(int a, int b, int N, int k, int i) {
        return (a * k + b + i * i) % N;
    }

    public static int doubleHashing(int a, int b, int N, int q, int k, int i) {
        return (a * k + b + i * (q - (k % q))) % N;
    }

    public boolean put(int k, int p) {
        if (emptySlot(p) || defuntSlot(p)) {
            buffer[p] = k;
            return true;
        }
        return false;
    }

    public boolean probe(int k, int p) {
        return buffer[p] == k;
    }

    public boolean emptySlot(int p) {
        return buffer[p] == -1;
    }

    public boolean defuntSlot(int p) {
        return buffer[p] == -2;
    }

    public boolean remove(int k, int p) {
        if (buffer[p] == k) {
            buffer[p] = -2;
            return true;
        }
        return false;
    }

    public void print() {
        for (int i = 0; i < buffer.length; i++) {
            System.out.println("Slot " + i + ": " + buffer[i]);
        }
    }

    public static void main(String[] args) {
        HashTable table = new HashTable(10);

        System.out.println("Initial table:");
        table.print();

        int a = 3, b = 5, N = 10, k = 7, q = 7;

        // Test hash function
        int h = HashTable.hash(a, b, N, k);
        System.out.println("\nhash(" + a + ", " + b + ", " + N + ", " + k + ") = " + h);

        // Test linear probing
        int lp = HashTable.linearProbing(a, b, N, k, 1);
        System.out.println("linearProbing = " + lp);

        // Test quadratic probing
        int qp = HashTable.quadraticProbing(a, b, N, k, 2);
        System.out.println("quadraticProbing = " + qp);

        // Test double hashing
        int dh = HashTable.doubleHashing(a, b, N, q, k, 1);
        System.out.println("doubleHashing = " + dh);

        // Put key in the table
        System.out.println("\nInserting key:");
        System.out.println("put(k=" + k + ", p=" + h + ") = " + table.put(k, h));

        // Print table after insertion
        table.print();

        // Probe key
        System.out.println("\nProbing key:");
        System.out.println("probe(k=" + k + ", p=" + h + ") = " + table.probe(k, h));

        // Remove key
        System.out.println("\nRemoving key:");
        System.out.println("remove(k=" + k + ", p=" + h + ") = " + table.remove(k, h));

        // Check defunct slot
        System.out.println("defuntSlot(p=" + h + ") = " + table.defuntSlot(h));

        // Print table after removal
        table.print();

        // Empty table
        System.out.println("\nEmptying table:");
        table.empty();
        table.print();
    }
}

