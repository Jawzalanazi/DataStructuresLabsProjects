public class item {

private String id;
private double Price;
private int Quantity;


public item ( String id, double Price, int Quantity){
    this.id=id;
    this.setPeice(Price);
    this.setQuantity(Quantity);

}

public String getId(){
    return id;
}

public int getQuantity(){
return Quantity;
}

public void setQuantity(int Quantity){
this.Quantity=Quantity;
}

public double getPrice(){
    return Price;
}
public void setPeice(double Price){
this.Price=Price;
}

public String toString(){
    return "id = " + id + "price= " + Price + "quantity= " + Quantity;
}

}