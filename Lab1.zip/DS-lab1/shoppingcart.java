public class shoppingcart {
    
    private int size;
    private item[] items = new item[size];
    private int count =0;

    public shoppingcart(int size){
   items  = new item [size];
    }

public void addItem(item item1){

    if (this.count < size) 
    this.items [this.count++]=  item1;
    else
    System.out.println("Failed to add, your cart is full");

    }

public void removeItem(String id){
   
for (int i = 0; i < count; i++) {
    if (items[i].getId().equals(id)) {
        count--;
        if (i != count)
            items[i] = items[count];
        items[count] = null;
        System.out.println("Item successfully removed from your cart");
    }
    else
    System.out.println("Failed to remove, the item not found in your cart");
}
}


public void viewItems() {
    System.out.println(toString());
}

@Override
public String toString() {
    String cartItems = "There are " + count + " item(s) in your cart.\n";
    for (int i = 0; i < count; i++) {
        cartItems += (i + 1) + " -" + items[i];
    }
    return cartItems;
}

public int getCount() {
    return count;
}
}