public abstract class store {

    protected String storeName;
    protected static int sizes=100;
    protected int productCount = 0;

    protected shoppingcart customerCart = new shoppingcart(0);
    protected item[] StoreProducts = new item[sizes];

    public abstract void readProduct(String fileName)throws Exception;
    public abstract void viewProduct();
    
    public item searchByID(String id) {
        for (int i = 0; i < productCount; i++) {
            if (StoreProducts[i].getId().equalsIgnoreCase(id))
                return StoreProducts[i];
        }
        return null;
    }

}
