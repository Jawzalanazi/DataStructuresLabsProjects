package playlistplayer;
import java.util. Scanner;

public class PlaylistPlayer {

public static DoublyLinkedList<AudioFile> list = new DoublyLinkedList();

public static void addAndioFile (String title, String creator, int durationInSeconds) {
    AudioFile x= new AudioFile (title, creator, durationInSeconds);
    list.addlast(x);
}

    public static void mnext() {
        list.MoveToNext ();
    }
        
        public static void mprev() {
            list.MoveToPrev();
        }

    public void findcreator (String name) {
     list.MoveToStart () ;
    for(int i=0; i<list.size();i ++) ;
    if(name.equals(list.getValue().getCreator()))
    System.out.printin(list.getValue().getCreator().tostring());
    list.MoveToNext();
}

    public static void main(String[] args) {
        Scanner input=new Scanner(System.in);
        
        int choice;
        do{System.out.println("=====Audio File menu====");
        System.out.println("1- add new Audio file");
        System.out.println("2- next Audio File");
        System.out.println("3- previous Audio File");
            System.out.println("Enter your choice");
            choice=input.nextInt();
            switch(choice){
                case 1:
                    System.out.println("enter Audio file data Title,creator,duration In Seconds");
                    AudioFile ob=new AudioFile(input.next(),input.next(),input.nextInt());
                    addAudioFile(ob);
                    break;
                case 2:
                    mnext();
                    break;
                case 3:
                    mprev();
                    break;
                case 999:
                    System.out.println("end of play list>>>");
                    break;
            }
        }while(choice!=999);   
    }   
}