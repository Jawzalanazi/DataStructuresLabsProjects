public class Printer {

      public static int max=100;
      public static LinkedStack<Page> doc = new LinkedStack<Page>();
      public static LinkedStack<Page> temp = new LinkedStack<Page>();
      
      public static void addPage(int size){
        for (int i=0; i<= size; i++){
            if(doc.size()< max){
                Page p = new Page("Page " +i, i);
                doc.push(p);
            }
        }
      }


       public static void printPage(String text, int pageNum){
          System.out.println("Printing the Page: " + text); 
           for (int i = 0; i < pageNum; i++) {
         if(!doc.isEmpty()){
            doc.pop();
            System.out.println("Page: "+(i+1));
        }
         else
         System.out.println("Cannot complete job! add papers to the printer please."); 
                break; 
      }
    }

      public static void check(){
        int counter= 0;

          while(!doc.isEmpty()){
            System.out.println(doc.pop());
            counter++;
        }
        while(!temp.isEmpty()){
         doc.push(temp.pop());   
        }
        int x= max - counter;
        if(x>0)
        System.out.println("remining pages : "+ x);
        else
        System.out.println("no pages left");
      }



    public static void main(String[] args) {
        System.out.println("printer! ");
        System.out.println("Add 5 papers to stack");
       addPage(5);
        System.out.println();

        System.out.println("Add 10 papers to stack");
        System.out.println();

        addPage(10);
        System.out.println();

        printPage("1", 2);
        System.out.println();
        System.out.println("Add 50 papers to stack");
        System.out.println();

        addPage(5);
        System.out.println();

        printPage("3", 5);

        System.out.println();

        printPage("4", 6);
        check();
         addPage(5);
    
   }
}