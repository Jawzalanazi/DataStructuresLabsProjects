public class Page {
    
    public String text;
    public int pageNum;

public Page(String text, int pageNum){
    this.text= text;
    this.pageNum= pageNum;
}

public String getText(){
    return text;
}
public int getPageNum(){
    return pageNum;
}
public void setText(String text){
    this.text=text;
}
public void setPageNum(int pageNum){
    this.pageNum=pageNum;
}

@Override
public String toString(){
    return "text" + text + "page number"+ pageNum;
}
}
