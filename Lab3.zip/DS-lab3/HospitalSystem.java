import java.nio.file.Paths;
import java.util.Scanner;

import cs252_lab3_sll.Doctor;
import cs252_lab3_sll.Patient;
import cs252_lab3_sll.SinglyLinkedList;

public class HospitalSystem {

    static Scanner input;

static SinglyLinkedList<Doctor>doctors=new SinglyLinkedList();
static SinglyLinkedList<Patient>patients=new SinglyLinkedList();


    public HospitalSystem() { // reading from file
        try {
            Addoctors("doctors.txt");
        } catch (Exception ex) {
            System.out.println("Failed to read from the file.");
        }
    }

    public void Addoctors(String fileName) throws Exception {
        input = new Scanner(Paths.get(fileName));
         while (input.hasNext()) {
            doctors.addLast(new Doctor(input.next(), input.next(), input.next()));
        }
        input.close();
    }

public static void print_doctor(){ // print doctor list
    doctors.moveToStart();
    for(int i=0;i<doctors.size();i++){
    System.out.println(doctors.getValue());
    doctors.next();
}
}

public static void print_Patient(){ // Print patient information from the waiting list by the ID
    patients.moveToStart();
    for(int i=0;i<patients.size();i++){
    System.out.println(patients.getValue());
    patients.next();
}
}

  public static void Add_patient(){ // Adding patient to the waiting list
         patients.addLast(new Patient("130",19,"jeje","Urology"));
         patients.addLast(new Patient("140",19,"joye","Dermatology"));
          patients.addLast(new Patient("150",19,"jane","Pediatrics"));
    } 
    
   public static Patient Search_patient(String id){ // Search and return patient information from the waiting list by the ID
       patients.moveToStart();
       for(int i=0;i<patients.size();i++){
        Patient p=patients.getValue();
       if(p.getId().equals(id))
       return p;
      patients.next();
          }
       return null;
              }
   
   public static void Remove_Patient(String id){ // Remove a patient record from the waiting list by the ID
    patients.moveToStart();
       for(int i=0;i<patients.size();i++){
        Patient p=patients.getValue();
       if(p.getId().equals(id)){ 
        patients.remove(i);
       break;
    }
       patients.next();
              }
   }
   
    public static void Assigning_patient_to_doctor(String id){ //Assigning the patient to a doctor according to the clinic name
        Patient p=Search_patient(id);
        if(p==null)
        return;
        String clinic=p.getclinic();
        doctors.moveToStart();
        Doctor d=null;
        for(int i=0;i<doctors.size();i++){
        if(doctors.getValue().getSpecialty().equals(clinic)){
            d=doctors.getValue();
        break;
        }
        doctors.next();
        }
        if(d!=null)       
       System.out.println(" the patient "+p.getName()+ "  Assigned to doctor "+d.getName());
        
       else
       System.out.println("system Error!!");
    }

    
    public static void main(String[] args) {
        HospitalSystem x = new HospitalSystem();
        input = new Scanner(System.in);
        int choice = 0;
        System.out.println("Welcome to the Hospital System");
        do {
            System.out.println("\nWould you like to: ");
            System.out.println("1- Print the Doctors list");
            System.out.println("2- Add a patient to the waiting list");
            System.out.println("3- Print patient information from the waiting list by the ID");
            System.out.println("4- Remove a patient record from the waiting list by the ID");
            System.out.println("5-  Exit .");

            System.out.print("Enter the number of your selection:  ");
            choice = input.nextInt();

            switch (choice) {
                case 1:// Print the Doctors list
                print_doctor();
                    break;

                case 2:// Adding patient to the waiting list
                   Add_patient();
                    break;

                case 3:// Print patient information from the waiting list by the ID
                   print_Patient();
                    break;

                case 4:// Remove a patient record from the waiting list by the ID
                    System.out.println("enter patient id to remove");
                    Remove_Patient(input.next());
                    break;

                case 5: // Exit
                    System.out.println("Thank you, See you soon.");
                    break;
            }
        } while (choice != 5);
    }
}