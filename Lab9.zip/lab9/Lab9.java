/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab9;

/**
 *
 * @author 443020299
 */
public class Lab9 {

   
    /**
     * @param args the command line arguments
     */
    
    
    
    
    public static void main(String[] args) {
        // TODO code application logic here
        
        BinaryTree<Integer> bt = new BinaryTree<Integer>();
          TNode<Integer> r = bt.addRoot(7);
          TNode<Integer> lr = bt.addLeft(r,8);
          TNode<Integer> rr = bt.addRight(r,9);

          TNode<Integer> llr = bt.addLeft(lr,10);
          TNode<Integer> rlr = bt.addRight(lr,16);
        
          TNode<Integer> lrr = bt.addLeft(rr,12);
          TNode<Integer> rrr = bt.addRight(rr,20);
         
        System.out.print(" the tree in inOrder "); bt.inOrder(r); 
        System.out.println();
        System.out.print(" the tree in postOrder "); bt.postOrder(r); 
        System.out.println();
        System.out.print(" the tree in preOrder "); bt.preOrder(r); 
        System.out.println();
        
        System.out.println("the size of the tree " +  bt.size(r));
        System.out.println("the count Occurrence of the number 9 is " +  bt.countOccurrence(r, 9));
        System.out.println("the sum of the the tree is " +  bt.CalcSum(r));
        System.out.println("the sum of the Internal nodes is " +  bt.InternalCount(r));
        
        bt.check(r);
    }
}
