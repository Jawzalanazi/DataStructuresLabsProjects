public class test {
    
       public static void bubbleSort(course[] a ){
     for(int i=0;i<a.length-1;i++){
       for(int j=1;j<a.length-i;j++){
          if(a[j-1].getCourse_name().compareTo(a[j].getCourse_name())>0){
     
              course temp=a[j-1];
               a[j-1]=a[j];
               a[j]=temp;
          }
        }
    }
}
    
static boolean FindByName (student s,String name){
return binarySearch(s.getAcademic_record(),name,0,s.getAcademic_record().length-1);
}
   static boolean binarySearch(course[] data,String target,int low,int high) {
   if(low>high)
       return false;
   else
   {int mid=(low+high)/2;
   if(target.equals(data[mid].getCourse_name()))
       return true;
   else
       if(target.compareTo(data[mid].getCourse_name())<0)
           return binarySearch(data,target,low,mid-1);
   else
          return binarySearch(data,target,mid+1,high); 
        }
    }
   
   static void FindByID ( student s,String id){
       course c[]=s.getAcademic_record();
       boolean flag=false;
   for(int i=0;i<c.length;i++){
    if(c[i].getId().equals(id))
        flag=true;
   }
   if(flag)
           System.out.println(" found ");
    else
           System.out.println("not found");   
   }
   
    public static void main(String[] args) {
      course cor[]=new course[4];
 cor[0]=new course("333","c#",4,100);
 cor[1]=new course("111","math",6,100);
 cor[2]=new course("444","english",2,100);
 cor[3]=new course("222","java",4,100);

 student s1=new student("0000","Ahmad",cor);
        bubbleSort(s1.getAcademic_record());
        
        System.out.println("couse after sorting \n"+s1);
        System.out.println(" ... check is fount? "+FindByName(s1, "c#"));
 
 student s2=new student("8888","Omar",cor);
     System.out.println("\n "+s2);
        FindByID(s2, "777");
    }   
}