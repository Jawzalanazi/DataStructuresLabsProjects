import java.util.Arrays;
public class student {
    
  private String  id;
   private String name;
   private course  academic_record[]; 

    public student(String id, String name, course[] academic_record) {
        this.id = id;
        this.name = name;
        this.academic_record = academic_record;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public course[] getAcademic_record() {
        return academic_record;
    }

    public void setAcademic_record(course[] academic_record) {
        this.academic_record = academic_record;
    }

    @Override
    public String toString() {
        
        return "student{" + "id=" + id + ", name=" + name + "\n [ academic_record] " +Arrays.toString( academic_record )+ '}';
    }
}