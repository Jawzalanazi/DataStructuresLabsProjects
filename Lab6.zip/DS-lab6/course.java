public class course 
{
  private String id;
  private String course_name;
  private int credit_hours; 
  private int grade;

    public course(String id, String course_name, int credit_hours, int grade){
        this.id = id;
        this.course_name = course_name;
        this.credit_hours = credit_hours;
        this.grade = grade;
    }

    public String getId(){
        return id;
    }

    public void setId(String id){
        this.id = id;
    }

    public String getCourse_name(){
        return course_name;
    }

    public void setCourse_name(String course_name){
        this.course_name = course_name;
    }

    public int getCredit_hours(){
        return credit_hours;
    }

    public void setCredit_hours(int credit_hours){
        this.credit_hours = credit_hours;
    }

    public int getGrade(){
        return grade;
    }

    public void setGrade(int grade){
        this.grade = grade;
    }

    @Override
    public String toString(){
        return "course{" + "\n id=" + id + " , course_name=" + course_name + ", credit_hours=" + credit_hours + ", grade=" + grade + '}';
    } 
}